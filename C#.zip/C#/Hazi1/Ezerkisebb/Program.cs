﻿
//using System.Linq;

class Program
{
    private static void Main(string[] args)
    {
        int sum = 0;
        for (int i = 1; i < 1000; i++) if (i % 3 == 0 || i % 5 == 0) sum += i;
        Console.WriteLine(sum);

        //int sum = Enumerable.Range(1, 999).Where(n => n % 3 == 0 || n % 5 == 0).Sum();
        //Console.WriteLine(sum);
    }
}