﻿using static System.Console;

namespace Homework2
{
    class Homework2
    {
        // E. verbing
        private static string Verbing(string s)
        {
            if (s.Length < 3)
            {
                return s;
            }
            if (s.EndsWith("ing"))
            {
                return s + "ly";
            }
            return s + "ing";
        }

        // F. not_bad
        private static string NotBad(string s)
        {
            int notIndex = s.IndexOf("not");
            int badIndex = s.IndexOf("bad");

            if (notIndex != -1 && badIndex != -1 && badIndex > notIndex)
            {
                return s.Substring(0, notIndex) + "good" + s.Substring(badIndex + 3);
            }

            return s;
        }

        // G. front_back
        private static string FrontBack(string a, string b)
        {
            string SplitInTwo(string str)
            {
                int splitIndex = (str.Length + 1) / 2; // Az első rész hosszabb, ha páratlan
                return str.Substring(0, splitIndex) + "|" + str.Substring(splitIndex);
            }

            string[] aParts = SplitInTwo(a).Split('|');
            string[] bParts = SplitInTwo(b).Split('|');

            return aParts[0] + bParts[0] + aParts[1] + bParts[1];
        }

        private static void Test(string got, string expected)
        {
            var prefix = (got == expected ? " OK " : "  X ");
            WriteLine($"{prefix} got: {got}; expected: {expected}");
        }

        public static void Main(string[] args)
        {
            WriteLine("verbing");
            Test(Verbing("hail"), "hailing");
            Test(Verbing("swiming"), "swimingly");
            Test(Verbing("do"), "do");

            WriteLine();
            WriteLine("not_bad");
            Test(NotBad("This movie is not so bad"), "This movie is good");
            Test(NotBad("This dinner is not that bad!"), "This dinner is good!");
            Test(NotBad("This tea is not hot"), "This tea is not hot");
            Test(NotBad("It's bad yet not"), "It's bad yet not");

            WriteLine();
            WriteLine("front_back");
            Test(FrontBack("abcd", "xy"), "abxcdy");
            Test(FrontBack("abcde", "xyz"), "abcxydez");
            Test(FrontBack("Kitten", "Donut"), "KitDontenut");
        }
    }
}
