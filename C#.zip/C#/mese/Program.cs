﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

class Program
{
    static void Main(string[] args)
    {
        if (args.Length != 1)
        {
            Console.WriteLine("Adj meg egy szereplő nevet parancssori argumentumként!");
            return;
        }

        string keresettSzereplo = args[0];
        List<Mese> mesek = new List<Mese>();

        try
        {
            foreach (string sor in File.ReadAllLines("input.txt"))
            {
                string[] reszek = sor.Split(':');
                string cim = reszek[0].Trim();
                List<string> szereplok = reszek[1].Split(',').Select(s => s.Trim()).ToList();
                mesek.Add(new Mese(cim, szereplok));
            }
        }
        catch (IOException e)
        {
            Console.WriteLine("Hiba a fájl olvasása közben: " + e.Message);
        }

        List<Mese> talalatok = mesek
            .Where(m => m.Szereplok.Contains(keresettSzereplo))
            .OrderByDescending(m => m.SzereplokSzama)
            .ThenBy(m => m.Cim)
            .ToList();

        foreach (Mese mese in talalatok)
        {
            Console.WriteLine(mese);
        }

        try
        {
            using (StreamWriter sw = new StreamWriter("ki.txt"))
            {
                foreach (Mese mese in talalatok)
                {
                    sw.WriteLine(mese.ToString());
                }
            }
        }
        catch (IOException e)
        {
            Console.WriteLine("Hiba a fájl írása közben: " + e.Message);
        }
    }
}

class Mese : IComparable<Mese>
{
    public string Cim { get; }
    public List<string> Szereplok { get; }

    public Mese(string cim, List<string> szereplok)
    {
        Cim = cim;
        Szereplok = szereplok;
    }

    public int SzereplokSzama => Szereplok.Count;

    public override string ToString()
    {
        return $"{Cim}:{SzereplokSzama}";
    }

    public int CompareTo(Mese other)
    {
        if (SzereplokSzama == other.SzereplokSzama)
        {
            return String.Compare(Cim, other.Cim, StringComparison.Ordinal);
        }
        return other.SzereplokSzama.CompareTo(SzereplokSzama); // Csökkenő sorrend
    }
}
