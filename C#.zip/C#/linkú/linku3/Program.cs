﻿using System;
using System.Collections.Generic;
using System.Linq;

class Product
{
    public string Name { get; set; }
    public string Category { get; set; }
    public double Price { get; set; }

    public Product(string name, string category, double price)
    {
        Name = name;
        Category = category;
        Price = price;
    }
}

class Program
{
    static void Main(string[] args)
    {
        var products = new List<Product>
        {
            new Product("Laptop", "Elektronika", 320000),
            new Product("Okostelefon", "Elektronika", 150000),
            new Product("Televízió", "Elektronika", 200000),
            new Product("Farmer", "Ruházat", 12000),
            new Product("Pulóver", "Ruházat", 8000),
            new Product("Kenyér", "Élelmiszer", 450),
            new Product("Tej", "Élelmiszer", 350),
            new Product("Sajt", "Élelmiszer", 1500)
        };

        Console.WriteLine("1. Kategória szerinti csoportosítás:");
        var groupedByCategory=products.GroupBy(x => x.Category);
        foreach(var group in groupedByCategory)
        {
            Console.WriteLine($"\n Kategória: {group.Key}");
            foreach(var item in group)
            {
                Console.WriteLine($" - {item.Name}");
            }
        }

        Console.WriteLine();
        Console.WriteLine("2. Legolcsóbb termék:");
        var cheapProd=products.OrderBy(x => x.Price).First();
        Console.WriteLine($"Legolcsobb termek: {cheapProd.Name}, ara: {cheapProd.Price}");

        Console.WriteLine();

        string selectedCategory = "Elektronika";
        Console.WriteLine($"3. Átlagár kiszámítása a(z) '{selectedCategory}' kategóriában:");
        var AvgPriceCat=products.Where(p=>p.Category==selectedCategory).Average(x=>x.Price);
        Console.WriteLine($"Az átlagár a(z) '{selectedCategory}' kategóriában: {AvgPriceCat:F2} Ft");

    }
}