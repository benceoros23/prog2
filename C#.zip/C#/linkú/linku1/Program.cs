﻿using System;
using System.Collections.Generic;
using System.Linq;

class Employee
{
    public string Name { get; set; }
    public int Age { get; set; }
    public double Salary { get; set; }

    public Employee(string name, int age, double salary)
    {
        Name = name;
        Age = age;
        Salary = salary;
    }
}

class Program
{
    static void Main(string[] args)
    {
        var employees = new List<Employee>
        {
            new Employee("Kovács István", 25, 320000),
            new Employee("Nagy Anna", 40, 450000),
            new Employee("Szabó Béla", 35, 380000),
            new Employee("Tóth László", 28, 290000),
            new Employee("Kis Péter", 22, 250000)
        };

        Console.WriteLine("1. 30 év alatti dolgozók fizetés szerint csökkenő sorrendben:");
        var youngEmployees = employees
            .Where(e => e.Age < 30) // Szűrés
            .OrderByDescending(e => e.Salary) // Rendezes csökkenő sorrendben fizetés szerint
            .ToList();

        foreach (var emp in youngEmployees)
        {
            Console.WriteLine($"{emp.Name}, Kor: {emp.Age}, Fizetés: {emp.Salary} Ft");
        }

        Console.WriteLine();

        Console.WriteLine("2. Dolgozók átlagfizetése:");
        var averageSalary=employees.Average(e => e.Salary);
        Console.WriteLine($"Átlagfizetés: {averageSalary:F2} Ft");

        Console.WriteLine();


        Console.WriteLine("3. Legidősebb dolgozó:");
        var oldestEmployee =employees.OrderByDescending(e => e.Age).First();
        Console.WriteLine($"A legidősebb dolgozó: {oldestEmployee.Name}, Kor: {oldestEmployee.Age}");

    }

}