﻿using System;
using System.Collections.Generic;
using System.Linq;

class Program
{
    class Student
    {
        public int StudentId { get; set; }
        public string Name { get; set; }
    }

    class Course
    {
        public int CourseId { get; set; }
        public string CourseName { get; set; }
    }

    class Enrollment
    {
        public int StudentId { get; set; }
        public int CourseId { get; set; }
    }

    static void Main()
    {
        var students = new List<Student>
        {
            new Student { StudentId = 1, Name = "Kiss Péter" },
            new Student { StudentId = 2, Name = "Nagy Anna" },
            new Student { StudentId = 3, Name = "Tóth Balázs" }
        };

        var courses = new List<Course>
        {
            new Course { CourseId = 101, CourseName = "Matematika" },
            new Course { CourseId = 102, CourseName = "Fizika" },
            new Course { CourseId = 103, CourseName = "Kémia" }
        };

        var enrollments = new List<Enrollment>
        {
            new Enrollment { StudentId = 1, CourseId = 101 },
            new Enrollment { StudentId = 1, CourseId = 102 },
            new Enrollment { StudentId = 2, CourseId = 103 }
        };

        var studentCourses = from enrollment in enrollments
                             join student in students on enrollment.StudentId equals student.StudentId
                             join course in courses on enrollment.CourseId equals course.CourseId
                             select new
                             {
                                 StudentName=student.Name,
                                 CourseName=course.CourseName,
                             };
        Console.WriteLine("Hallgatók által felvett tantárgyak:");
        foreach (var sc in studentCourses)
        {
            Console.WriteLine($"{sc.StudentName} -> {sc.CourseName}");
        }
        Console.WriteLine();

        var courseStudentCount= from enrollment in enrollments
                                group enrollment by enrollment.CourseId into courseGroup
                                join course in courses on courseGroup.Key equals course.CourseId
                                select new
                                {
                                    CourseName = course.CourseName,
                                    StudentCount = courseGroup.Count()
                                };
        Console.WriteLine("\nTantárgyankénti hallgatószám:");
        foreach (var cs in courseStudentCount)
        {
            Console.WriteLine($"{cs.CourseName}: {cs.StudentCount} hallgató");
        }

        // 3. Hallgatók nélküli tantárgyak
        var coursesWithoutStudents = from course in courses
                                     join enrollment in enrollments on course.CourseId equals enrollment.CourseId into courseEnrollments
                                     where !courseEnrollments.Any()
                                     select course.CourseName;

        Console.WriteLine("\nHallgatók nélküli tantárgyak:");
        foreach (var courseName in coursesWithoutStudents)
        {
            Console.WriteLine(courseName);
        }

    }
}