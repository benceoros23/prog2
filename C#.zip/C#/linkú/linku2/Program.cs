﻿using System;
using System.Collections.Generic;
using System.Linq;

class Program
{
    static void Main(string[] args)
    {
        var numbers = new List<int> { 12, 7, 3, 8, 21, 4, 10, 17, 2, 6 };

        Console.WriteLine("1. Páros számok és összegük:");
        var evenNumbers = numbers.Where(n => n % 2 == 0);
        int evenSum=evenNumbers.Sum();

        Console.WriteLine($"Páros számok: {string.Join(", ", evenNumbers)}");
        Console.WriteLine($"Összegük: {evenSum}");

        Console.WriteLine();
        Console.WriteLine("2. Legnagyobb szám a listában:");
        var maxNumbers = numbers.Max();
        Console.WriteLine($"Legnagyobb szám: {maxNumbers}");

        Console.WriteLine();

        Console.WriteLine("3. Számok rendezése és duplázása:");
        var doubledNumbers=numbers.OrderBy(n=>n).Select(n=>n*2).ToList();
        Console.WriteLine($"Rendezett, duplázott számok: {string.Join(", ", doubledNumbers)}");


    }
}