import java.io.*;
import java.util.*;

public class GalleryGenerator {
    private String rootDirectory;
    private final Stack<String> visitedDirectories = new Stack<>();

    public GalleryGenerator() {
        // Üres konstruktor
    }

    public void generateGallery(File directory) {
        if (!directory.isDirectory()) {
            return;
        }
        if (rootDirectory == null) {
            rootDirectory = directory.getAbsolutePath();
        }
        visitedDirectories.push(directory.getAbsolutePath());

        // HTML fájlok törlése az aktuális könyvtárban
        deleteHTMLFiles(directory);

        File[] files = directory.listFiles();
        List<File> imageFiles = new ArrayList<>();
        List<File> subDirectories = new ArrayList<>();

        if (files != null) {
            for (File file : files) {
                if (file.isDirectory()) {
                    subDirectories.add(file);
                } else if (isImageFile(file)) {
                    imageFiles.add(file);
                }
            }
        }

        generateHTMLForImages(directory, imageFiles);
        generateIndexHTML(directory, imageFiles, subDirectories);

        for (File subDir : subDirectories) {
            generateGallery(subDir);
        }

        visitedDirectories.pop();
    }

    private void deleteHTMLFiles(File directory) {
        File[] files = directory.listFiles();
        if (files != null) {
            for (File file : files) {
                if (file.isFile() && file.getName().endsWith(".html")) {
                    if (file.delete()) {
                        System.out.println("Törölve: " + file.getAbsolutePath());
                    } else {
                        System.out.println("Nem sikerült törölni: " + file.getAbsolutePath());
                    }
                }
            }
        }
    }

    private boolean isImageFile(File file) {
        String fileName = file.getName().toLowerCase();
        return fileName.endsWith(".jpg") || fileName.endsWith(".jpeg") || fileName.endsWith(".png");
    }

    private void generateIndexHTML(File directory, List<File> images, List<File> subDirectories) {
        String relativePath = getRelativePath(directory);

        try (PrintWriter writer = new PrintWriter(new FileWriter(directory + "/index.html"))) {
            writer.println("<!DOCTYPE html>");
            writer.println("<html>");
            writer.println("<head>");
            writer.println("<title>" + directory.getName() + "</title>");
            writer.println("</head>");
            writer.println("<body>");

            writer.println("<a href='" + relativePath + "index.html'><h2>Start Page</h2></a><br>");

            // "Vissza" gomb a szülő könyvtárra, ha nem gyökér
            if (!directory.getAbsolutePath().equals(rootDirectory)) {
                writer.println("<a href='../index.html'><button>Vissza</button></a><br>");
            }

            if (!subDirectories.isEmpty()) {
                writer.println("<hr>");
                writer.println("<h3>Directories:</h3>");
                writer.println("<ul>");
                for (File subDir : subDirectories) {
                    writer.println("<li><a href='" + subDir.getName() + "/index.html'>" + subDir.getName() + "</a></li>");
                }
                writer.println("</ul>");
            }

            if (!images.isEmpty()) {
                writer.println("<hr>");
                writer.println("<h3>Images:</h3>");
                writer.println("<ul>");
                for (File image : images) {
                    writer.println("<li><a href='" + image.getName() + ".html'>" + image.getName() + "</a></li>");
                }
                writer.println("</ul>");
            }

            writer.println("</body>");
            writer.println("</html>");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void generateHTMLForImages(File directory, List<File> images) {
        for (File image : images) {
            generateHTMLForImage(directory, images, image);
        }
    }

    private void generateHTMLForImage(File directory, List<File> images, File imageFile) {
        String imageName = imageFile.getName();
        int currentIndex = images.indexOf(imageFile);
        String imageHTMLPath = directory + "/" + imageName + ".html";
        String relativePath = getRelativePath(directory); // Relatív út az indexhez

        try (PrintWriter writer = new PrintWriter(new FileWriter(imageHTMLPath))) {
            writer.println("<!DOCTYPE html>");
            writer.println("<html>");
            writer.println("<head>");
            writer.println("<title>" + imageName + "</title>");
            writer.println("<style>");
            writer.println(".nav-buttons { display: flex; justify-content: space-between; width: 100px; }");
            writer.println("img { cursor: pointer; }");
            writer.println("</style>");
            writer.println("</head>");
            writer.println("<body>");

            // "Start Page" link
            writer.println("<a href='" + relativePath + "index.html'><h2>Start Page</h2></a><br>");

            // "Vissza" gomb hozzáadása az aktuális könyvtár indexéhez
            writer.println("<a href='index.html'><button>Vissza</button></a><br>");

            // Navigációs gombok
            writer.println("<div class='nav-buttons'>");
            if (currentIndex > 0) {
                File prevImage = images.get(currentIndex - 1);
                writer.println("<a href='" + prevImage.getName() + ".html'><span class='arrow'>&#9668;</span></a>");
            } else {
                writer.println("<span class='arrow disabled'>&#9668;</span>");
            }
            if (currentIndex < images.size() - 1) {
                File nextImage = images.get(currentIndex + 1);
                writer.println("<a href='" + nextImage.getName() + ".html'><span class='arrow'>&#9658;</span></a>");
            } else {
                writer.println("<span class='arrow disabled'>&#9658;</span>");
            }
            writer.println("</div>");

            // Kép megjelenítése
            writer.println("<img src='" + imageName + "' alt='" + imageName + "' ");
            if (currentIndex < images.size() - 1) {
                File nextImage = images.get(currentIndex + 1);
                writer.println("onclick=\"window.location.href='" + nextImage.getName() + ".html'\"");
            }
            writer.println("><br>");
            writer.println("<p>" + imageName + "</p>");

            writer.println("</body>");
            writer.println("</html>");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private String getRelativePath(File directory) {
        StringBuilder relativePath = new StringBuilder();
        File current = directory;

        while (current != null && !current.getAbsolutePath().equals(rootDirectory)) {
            relativePath.insert(0, "../");
            current = current.getParentFile();
        }

        return relativePath.toString();
    }
}
