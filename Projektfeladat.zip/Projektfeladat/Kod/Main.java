import java.io.File;

public class Main {
    public static void main(String[] args) {
        if (args.length == 0) {
            System.out.println("Kérem adjon meg egy gyökérkönyvtárat!");
            return;
        }

        String rootDirectory = args[0];
        File root = new File(rootDirectory);

        if (!root.isDirectory()) {
            System.out.println("A megadott elérési út nem egy könyvtár!");
            return;
        }

        GalleryGenerator generator = new GalleryGenerator();
        generator.generateGallery(root);
    }
}