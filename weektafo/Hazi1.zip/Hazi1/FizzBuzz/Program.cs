﻿using System;

class FizzBuzz
{
    private int limit;

    // Konstruktor, ami beállítja a felső limitet
    public FizzBuzz(int limit)
    {
        this.limit = limit;
    }

    // A FizzBuzz logika, amit a start() metódus hív meg
    public void Start()
    {
        for (int i = 1; i <= limit; i++)
        {
            // Ellenőrizzük, hogy a szám osztható-e 3-mal és 5-tel
            if (i % 3 == 0 && i % 5 == 0)
            {
                Console.WriteLine("fizzbuzz");
            }
            // Ellenőrizzük, hogy a szám osztható-e 3-mal
            else if (i % 3 == 0)
            {
                Console.WriteLine("fizz");
            }
            // Ellenőrizzük, hogy a szám osztható-e 5-tel
            else if (i % 5 == 0)
            {
                Console.WriteLine("buzz");
            }
            // Ha egyik feltétel sem teljesül, akkor a számot írjuk ki
            else
            {
                Console.WriteLine(i);
            }
        }
    }
}

class Program
{
    static void Main()
    {
        // Létrehozzuk a FizzBuzz objektumot 100-as felső limitel
        FizzBuzz fb = new FizzBuzz(100);
        // Elindítjuk a FizzBuzz kimenetet
        fb.Start();
    }
}
