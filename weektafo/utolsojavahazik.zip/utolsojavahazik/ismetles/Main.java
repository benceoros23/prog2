import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class Main {
    public static void main(String[] args) {
        // Adott lista inicializálása
        List<Integer> numbers = List.of(5, 2, 3, 5, 1, 4, -200, 5, 1, 3, 2, 2, 5);
        
        // Duplikátumok eltávolítása a Set segítségével
        Set<Integer> uniqueNumbersSet = new HashSet<>(numbers);
        
        // A Set visszaalakítása listává
        List<Integer> uniqueNumbersList = new ArrayList<>(uniqueNumbersSet);
        
        // Lista rendezése
        Collections.sort(uniqueNumbersList);
        
        // Eredmény kiírása
        System.out.println("Egyedi, rendezett lista: " + uniqueNumbersList);
    }
}
