import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;

public class Main {
    // Konstansok a sorok és szavak számának beállításához
    private static final int ROWS = 10;      // Sorok száma
    private static final int WORDS_PER_ROW = 15;  // Szavak száma egy sorban
    private static final String FILE_NAME = "generated_data.txt"; // Kimeneti fájl neve

    public static void main(String[] args) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_NAME))) {
            Random random = new Random();

            // Sorok generálása
            for (int i = 0; i < ROWS; i++) {
                StringBuilder line = new StringBuilder();

                // Szavak generálása
                for (int j = 0; j < WORDS_PER_ROW; j++) {
                    char firstLetter = (char) ('a' + random.nextInt(3)); // 'a', 'b' vagy 'c'
                    char secondDigit = (char) ('0' + random.nextInt(10)); // '0'-'9'

                    line.append(firstLetter).append(secondDigit);

                    if (j < WORDS_PER_ROW - 1) {
                        line.append(" "); // Szóköz a szavak között
                    }
                }

                writer.write(line.toString());
                writer.newLine(); // Új sor
            }

            System.out.println("Adathalmaz sikeresen generálva a(z) " + FILE_NAME + " fájlba.");
        } catch (IOException e) {
            System.out.println("Hiba történt a fájl írása közben: " + e.getMessage());
        }
    }
}
