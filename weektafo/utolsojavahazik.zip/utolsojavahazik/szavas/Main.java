import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class Main {
    public static void main(String[] args) {
        String fileName = "input.txt"; // Az állomány neve

        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            Map<String, Integer> wordCountMap = new HashMap<>();
            String line;
            
            // 1. Soronként olvassuk be az állományt
            while ((line = reader.readLine()) != null) {
                // 2. Szavakra bontás szóközök mentén
                String[] words = line.split("\\s+");
                for (String word : words) {
                    wordCountMap.put(word, wordCountMap.getOrDefault(word, 0) + 1);
                }
            }
            
            // Kérdés 1: Hány különböző szó van?
            System.out.println("Különböző szavak száma: " + wordCountMap.size());
            
            // Kérdés 2: Minden szó előfordulásának kiírása
            System.out.println("\nSzavak előfordulásai:");
            for (Map.Entry<String, Integer> entry : wordCountMap.entrySet()) {
                System.out.println(entry.getKey() + ": " + entry.getValue());
            }
            
            // Kérdés 3: Leggyakoribb szó megtalálása
            String mostFrequentWord = null;
            int maxCount = 0;

            for (Map.Entry<String, Integer> entry : wordCountMap.entrySet()) {
                if (entry.getValue() > maxCount) {
                    mostFrequentWord = entry.getKey();
                    maxCount = entry.getValue();
                }
            }

            if (mostFrequentWord != null) {
                System.out.println("\nLeggyakrabban előforduló szó: " + mostFrequentWord + " (" + maxCount + " alkalommal)");
            }

        } catch (IOException e) {
            System.out.println("Hiba történt az állomány beolvasása közben: " + e.getMessage());
        }
    }
}
